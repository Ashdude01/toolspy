# Facebook Photo Downloader (Firefox WebExtension)

Scan the **current tab** for image URLs (`img`, `picture`/`srcset`, `video` poster, and common Facebook CDN links). Select thumbnails, then:

- **Download selected** — saves each file via the Downloads API  
- **Download ZIP** — fetches selected URLs in the background script and builds a ZIP (uncompressed STORE format; AMO-safe, no third-party ZIP library)  
- **Compress images** / **Convert images** — opens [Toolspy Image Compressor](https://toolspy.net/image-compressor) / [Image Converter](https://toolspy.net/image-converter) with `extension_data` (query or hash for long URL lists)

## Builds for other browsers

Ready-to-load sibling folders (same behaviour, Chromium uses `service_worker`):

| Folder | Browser |
|--------|---------|
| `facebook-photo-downloader-chrome` | Google Chrome |
| `facebook-photo-downloader-edge` | Microsoft Edge |
| `facebook-photo-downloader-opera` | Opera |
| `facebook-photo-downloader-safari` | Safari (see **`SAFARI-BUILD.md`** inside that folder — Xcode on macOS) |

This folder targets **Firefox** (`background.scripts` + `browser_specific_settings.gecko`).

## Load in Firefox (temporary)

1. Open `about:debugging#/runtime/this-firefox`  
2. **Load Temporary Add-on…**  
3. Select `extensions/facebook-photo-downloader-firefox/manifest.json`

## Requirements

- Firefox **140+** (Manifest V3). Matches support for `data_collection_permissions` (AMO requirement); use current stable Firefox.

## Permissions

- `downloads`, `tabs`, `activeTab`, `scripting` — scan active tab, inject the collector if needed, download files / ZIP  
- `host_permissions: <all_urls>` — fetch image bytes for ZIP and follow image URLs (required for cross-origin CDN URLs)

## Icons

Placeholder PNGs live under `icons/`. Replace with branded 48 / 96 / 128 assets before AMO submission.

## Privacy

Image URLs are processed locally. Opening Toolspy sends selected URLs only in the **Compressor / Converter** link (`extension_data` query or hash). No separate analytics are added by this extension.
