const ext = globalThis.browser ?? globalThis.chrome;

const els = {
  scan: document.getElementById("btn-scan"),
  badge: document.getElementById("badge"),
  status: document.getElementById("status"),
  list: document.getElementById("list"),
  all: document.getElementById("btn-all"),
  none: document.getElementById("btn-none"),
  download: document.getElementById("btn-download"),
  zip: document.getElementById("btn-zip"),
  toolspy: document.getElementById("btn-toolspy"),
  toolspyConvert: document.getElementById("btn-toolspy-convert"),
};

/** @type {{ url: string, label?: string }[]} */
let images = [];
/** @type {Set<string>} */
const selected = new Set();

function shortNameFromUrl(url) {
  try {
    const u = new URL(url);
    const seg = u.pathname.split("/").filter(Boolean).pop() || "image";
    return seg.split("?")[0] || "image";
  } catch {
    return "image";
  }
}

function setStatus(text, kind) {
  els.status.textContent = text || "";
  els.status.className = "status" + (kind ? ` ${kind}` : "");
}

function selectedUrls() {
  return images.filter((im) => selected.has(im.url)).map((im) => im.url);
}

function updateActions() {
  const n = selected.size;
  const has = n > 0;
  els.download.disabled = !has;
  els.zip.disabled = !has;
  els.toolspy.disabled = !has;
  els.toolspyConvert.disabled = !has;
  els.badge.hidden = images.length === 0;
  els.badge.textContent = images.length ? `${n} / ${images.length} selected` : "";
}

function toggleUrl(url) {
  if (selected.has(url)) selected.delete(url);
  else selected.add(url);
}

function syncCardState(li, url) {
  const on = selected.has(url);
  li.classList.toggle("is-selected", on);
  const badge = li.querySelector(".select-badge");
  if (badge) {
    badge.setAttribute("aria-pressed", on ? "true" : "false");
    badge.textContent = on ? "✓" : "+";
    badge.title = on ? "Deselect" : "Select";
  }
}

function renderList() {
  els.list.innerHTML = "";

  if (images.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "No images yet. Click “Scan page”.";
    els.list.appendChild(li);
    updateActions();
    return;
  }

  images.forEach((im) => {
    const url = im.url;
    const li = document.createElement("li");
    li.className = "item-card";
    li.dataset.url = url;
    li.setAttribute("role", "listitem");
    li.tabIndex = 0;
    li.title = (im.label ? im.label + " — " : "") + url;
    if (selected.has(url)) li.classList.add("is-selected");

    const thumbBlock = document.createElement("div");
    thumbBlock.className = "thumb-block";

    const thumbWrap = document.createElement("div");
    thumbWrap.className = "thumb-wrap";

    const img = document.createElement("img");
    img.alt = "";
    img.loading = "lazy";
    img.src = url;

    const metaDims = document.createElement("div");
    metaDims.className = "meta-dims";
    metaDims.textContent = "…";

    img.onload = () => {
      metaDims.textContent = `${img.naturalWidth} × ${img.naturalHeight}`;
    };
    img.onerror = () => {
      thumbWrap.textContent = "—";
      thumbWrap.style.fontSize = "11px";
      thumbWrap.style.color = "#9aa0a6";
      metaDims.textContent = "—";
    };

    thumbWrap.appendChild(img);
    thumbBlock.appendChild(thumbWrap);

    const badgeBtn = document.createElement("button");
    badgeBtn.type = "button";
    badgeBtn.className = "select-badge";
    badgeBtn.textContent = selected.has(url) ? "✓" : "+";
    badgeBtn.setAttribute("aria-pressed", selected.has(url) ? "true" : "false");
    badgeBtn.title = selected.has(url) ? "Deselect" : "Select";
    badgeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleUrl(url);
      syncCardState(li, url);
      updateActions();
    });
    thumbBlock.appendChild(badgeBtn);

    const metaBlock = document.createElement("div");
    metaBlock.className = "meta-block";

    const metaName = document.createElement("div");
    metaName.className = "meta-name";
    metaName.textContent = shortNameFromUrl(url);
    metaName.title = url;

    metaBlock.appendChild(metaName);
    metaBlock.appendChild(metaDims);

    li.appendChild(thumbBlock);
    li.appendChild(metaBlock);

    li.addEventListener("click", (e) => {
      if (e.target.closest(".select-badge")) return;
      toggleUrl(url);
      syncCardState(li, url);
      updateActions();
    });

    li.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        toggleUrl(url);
        syncCardState(li, url);
        updateActions();
      }
    });

    els.list.appendChild(li);
  });

  updateActions();
}

async function ensureContentScript(tabId) {
  try {
    await ext.tabs.sendMessage(tabId, { type: "PING" });
  } catch {
    await ext.scripting.executeScript({
      target: { tabId },
      files: ["content/collect-images.js"],
    });
  }
}

async function scanPage() {
  setStatus("Scanning…");
  images = [];
  selected.clear();
  renderList();

  const [tab] = await ext.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    setStatus("No active tab.", "error");
    return;
  }

  const restricted =
    !tab.url ||
    tab.url.startsWith("about:") ||
    tab.url.startsWith("moz-extension:") ||
    tab.url.startsWith("chrome:") ||
    tab.url.startsWith("edge:") ||
    tab.url.startsWith("https://addons.mozilla.org");

  if (restricted) {
    setStatus("This page cannot be scanned (browser or add-ons page).", "error");
    return;
  }

  try {
    await ensureContentScript(tab.id);
    const res = await ext.tabs.sendMessage(tab.id, { type: "COLLECT_IMAGES" });
    if (!res?.ok) {
      setStatus(res?.error || "Scan failed.", "error");
      return;
    }
    const raw = Array.isArray(res.images) ? res.images : [];
    images = raw.slice().reverse();
    images.forEach((im) => selected.add(im.url));
    setStatus(images.length ? `Found ${images.length} image(s).` : "No images found.", images.length ? "ok" : "");
    renderList();
  } catch (e) {
    setStatus(e?.message || String(e), "error");
  }
}

async function downloadSelected() {
  const urls = selectedUrls();
  if (!urls.length) return;
  setStatus("Downloading…");
  let i = 0;
  for (const url of urls) {
    try {
      let filename = "image";
      try {
        const u = new URL(url);
        const last = u.pathname.split("/").filter(Boolean).pop();
        if (last && last.length < 180) filename = last.split("?")[0];
      } catch (_) {}
      await ext.downloads.download({ url, filename, saveAs: false, conflictAction: "uniquify" });
      i++;
    } catch (e) {
      console.warn(e);
    }
  }
  setStatus(`Started download for ${i} file(s).`, "ok");
}

async function zipSelected() {
  const urls = selectedUrls();
  if (!urls.length) return;
  setStatus("Building ZIP…");
  const res = await ext.runtime.sendMessage({
    type: "BUILD_ZIP",
    urls,
    filename: "facebook-photos",
  });
  if (res?.ok) {
    setStatus("ZIP download started.", "ok");
  } else {
    setStatus(res?.error || "ZIP failed.", "error");
  }
}

async function openToolspy() {
  const urls = selectedUrls();
  if (!urls.length) return;
  setStatus("Opening Toolspy…");
  const res = await ext.runtime.sendMessage({ type: "OPEN_TOOLSPY", urls });
  if (res?.ok) {
    setStatus("Opened image compressor.", "ok");
  } else {
    setStatus(res?.error || "Could not open Toolspy.", "error");
  }
}

async function openToolspyConverter() {
  const urls = selectedUrls();
  if (!urls.length) return;
  setStatus("Opening converter…");
  const res = await ext.runtime.sendMessage({ type: "OPEN_TOOLSPY_CONVERTER", urls });
  if (res?.ok) {
    setStatus("Opened image converter.", "ok");
  } else {
    setStatus(res?.error || "Could not open converter.", "error");
  }
}

els.scan.addEventListener("click", () => scanPage());
els.all.addEventListener("click", () => {
  images.forEach((im) => selected.add(im.url));
  renderList();
});
els.none.addEventListener("click", () => {
  selected.clear();
  renderList();
});
els.download.addEventListener("click", () => downloadSelected());
els.zip.addEventListener("click", () => zipSelected());
els.toolspy.addEventListener("click", () => openToolspy());
els.toolspyConvert.addEventListener("click", () => openToolspyConverter());

document.addEventListener("DOMContentLoaded", () => {
  renderList();
  scanPage();
});
