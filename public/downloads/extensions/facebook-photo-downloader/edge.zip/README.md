# Facebook Photo Downloader (Microsoft Edge)

Same Manifest V3 layout as the **Chrome** build (`service_worker` background). Safe to publish to the **Microsoft Edge Add-ons** store as-is.

## Load unpacked (development)

1. Open `edge://extensions`
2. Enable **Developer mode**
3. **Load unpacked** → choose this folder `facebook-photo-downloader-edge`.

Edge uses the Chromium extension engine; signing and review follow Microsoft’s Edge Add-ons process.
