# Facebook Photo Downloader (Google Chrome)

Chromium **Manifest V3** build: `background` is a **service worker**; `vendor/zip-store.js` is loaded with `importScripts` from `background.js` (same code as the Firefox build).

## Load unpacked (development)

1. Open `chrome://extensions`
2. Turn on **Developer mode**
3. **Load unpacked** → select this folder `facebook-photo-downloader-chrome` (the directory that contains `manifest.json`).

## Notes

- The same package is valid for any **Chromium**-based store that accepts MV3 (this folder is the reference for Edge, Opera, and Safari conversion).
- **Feature parity** with `../facebook-photo-downloader` (Firefox), including Toolspy **Image Compressor** / **Converter** integration.
