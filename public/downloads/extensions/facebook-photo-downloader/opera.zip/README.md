# Facebook Photo Downloader (Opera)

Opera is Chromium-based and supports extensions that match **Chrome Manifest V3**. This folder mirrors the Chrome build (`service_worker`).

## Load unpacked (development)

1. Open Opera’s extensions page (`opera://extensions` or **Menu → Extensions**).
2. Enable **Developer mode** if shown.
3. **Load unpacked** → select `facebook-photo-downloader-opera`.

Publishing goes through **Opera Add-ons** using the same ZIP as you would use for Chrome (same manifest shape).
