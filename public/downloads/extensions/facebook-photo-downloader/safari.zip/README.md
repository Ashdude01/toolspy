# Facebook Photo Downloader (Safari Web Extension)

Safari cannot use this folder as-is in the browser. Apple expects a **native Safari Web Extension wrapper** built with **Xcode on macOS**.

Use the **`SAFARI-BUILD.md`** steps in this folder: they point you at Apple’s `safari-web-extension-converter` command-line tool to convert this WebExtension package into an Xcode project, then archive for TestFlight / Mac App Store.

The WebExtension source here is intentionally identical to **`facebook-photo-downloader-chrome`** (MV3 + `service_worker`).
