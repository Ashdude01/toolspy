# Building the Safari Web Extension (macOS)

Safari loads extensions through a **host macOS/iOS app** created in Xcode. Apple ships a converter that wraps an existing Chrome MV3 extension.

## Prerequisites

- **macOS** with **Xcode** installed (App Store).
- This folder (`facebook-photo-downloader-safari`) — same contents as `facebook-photo-downloader-chrome`.

## Convert to an Xcode project

From **Terminal**, run (adjust the path to your clone):

```bash
cd "/path/to/Toolspy/extensions"
xcrun safari-web-extension-converter facebook-photo-downloader-safari \
  --swift \
  --project-location ./facebook-photo-downloader-safari-xcode \
  --app-name "Facebook Photo Downloader"
```

This creates `facebook-photo-downloader-safari-xcode/` with:

- A native shell app target  
- Your Web Extension embedded  

Open the generated `.xcodeproj` in Xcode, select your **Team** for signing, then **Run** on Safari (macOS) or follow Apple’s docs for iOS / distribution.

## References

- [Apple: Converting a web extension for Safari](https://developer.apple.com/documentation/safariservices/safari_web_extensions/converting_a_web_extension_for_safari)
- [Distributing Safari extensions](https://developer.apple.com/documentation/safariservices/distributing-your-apps-safari-web-extension)

After conversion, increment versions in **both** the Xcode app target and the embedded extension’s `manifest.json` when you ship updates.
