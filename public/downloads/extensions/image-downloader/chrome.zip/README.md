# Image Downloader (Chrome)

Universal **Manifest V3** extension: scan the active tab for images (`img`, `picture` / `srcset`, `video` poster, common CDN-style links). Generic branding:

- Title: **Image Downloader**
- Tagline: **Download images from any website.**
- Header **light/dark theme** toggle (preference saved with `chrome.storage.sync`)

**Other browsers:** sibling folders — `image-downloader-edge`, `image-downloader-opera`, `image-downloader-safari` (same MV3 package as this folder); `image-downloader-firefox` (Manifest V3 with `background.scripts` + `browser_specific_settings.gecko`).

## Load unpacked

1. `chrome://extensions` → **Developer mode**  
2. **Load unpacked** → select `extensions/image-downloader-chrome`.

## Packaging

ZIP this folder contents (with `manifest.json` at root) for Chrome Web Store submission.
