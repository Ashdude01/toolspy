(function () {
  "use strict";

  var ext = globalThis.browser ?? globalThis.chrome;

  function parseSrcset(srcset) {
    if (!srcset || !String(srcset).trim()) return [];
    return srcset.split(",").map(function (part) {
      var p = part.trim().split(/\s+/);
      var url = p[0];
      var w = 0;
      if (p[1]) {
        var m = String(p[1]).match(/^(\d+)w$/);
        if (m) w = parseInt(m[1], 10);
      }
      return { url: url, width: w };
    });
  }

  function bestFromSrcset(srcset) {
    var parts = parseSrcset(srcset);
    if (!parts.length) return null;
    parts.sort(function (a, b) {
      return b.width - a.width;
    });
    return parts[0].url;
  }

  function toAbsolute(url) {
    try {
      return new URL(url, document.baseURI).href;
    } catch (_) {
      return null;
    }
  }

  function isHttpLike(href) {
    return /^https?:\/\//i.test(href);
  }

  function collectImages() {
    var seen = new Set();
    var out = [];

    function add(url, label) {
      if (!url) return;
      var abs = toAbsolute(url);
      if (!abs || !isHttpLike(abs)) return;
      if (abs.indexOf("data:") === 0 || abs.indexOf("blob:") === 0) return;
      if (seen.has(abs)) return;
      seen.add(abs);
      out.push({ url: abs, label: label || "" });
    }

    document.querySelectorAll("picture source[srcset]").forEach(function (el) {
      var best = bestFromSrcset(el.getAttribute("srcset") || "");
      if (best) add(best, "picture");
    });

    document.querySelectorAll("img").forEach(function (img) {
      var u = img.currentSrc || img.src;
      if (img.srcset) {
        var b = bestFromSrcset(img.srcset);
        if (b) u = b;
      }
      add(u, "img");
    });

    document.querySelectorAll("video[poster]").forEach(function (v) {
      add(v.getAttribute("poster"), "poster");
    });

    document.querySelectorAll('a[href*="fbcdn.net"], a[href*="scontent"]').forEach(function (a) {
      add(a.href, "link");
    });

    return out;
  }

  ext.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
    if (msg && msg.type === "PING") {
      sendResponse({ ok: true });
      return true;
    }
    if (msg && msg.type === "COLLECT_IMAGES") {
      try {
        sendResponse({ ok: true, images: collectImages() });
      } catch (e) {
        sendResponse({ ok: false, error: String(e), images: [] });
      }
      return true;
    }
    return false;
  });
})();
