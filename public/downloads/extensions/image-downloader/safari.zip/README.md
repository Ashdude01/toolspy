# Image Downloader (Safari)

This folder is the same **WebExtension (Manifest V3)** source as `image-downloader-chrome`, ready to be wrapped for **Safari** with Apple’s **Safari Web Extension** tools (Xcode on macOS). The extension API surface matches Chromium: `service_worker` background, `downloads`, `scripting`, etc.

1. On a Mac, open the project in Xcode and follow Apple’s “Convert a web extension for Safari” / “Build a Safari app extension” flow, pointing at this directory.
2. Test in Safari; App Store distribution has additional requirements (icons, entitlements, app shell).

For day-to-day web development, use the **Chrome** or **Edge** folder on Windows; this tree exists so the same `background.js` + `vendor/zip-store.js` can ship on Safari after conversion.
