/* global buildStoredZipBlob */

if (typeof buildStoredZipBlob === "undefined" && typeof importScripts === "function") {
  try {
    importScripts("vendor/zip-store.js");
  } catch (e) {
    console.error("[image-downloader] zip-store importScripts failed", e);
  }
}

/** Chrome / Edge / Opera: `chrome`; Firefox: `browser` */
const ext = globalThis.browser ?? globalThis.chrome;

const TOOLSPY_COMPRESSOR = "https://toolspy.net/image-compressor";
const TOOLSPY_CONVERTER = "https://toolspy.net/image-converter";

/** Default compressor settings when opening Toolspy from the extension (matches site ?extension_data= format). */
const TOOLSPY_EXTENSION_DEFAULTS = {
  preset: "high-quality",
  quality: 43,
  format: "original",
  removeExifData: true,
  enableProgressive: false,
  targetFileSize: 5,
};

/** Default converter settings ({ images, settings }) — matches image-converter ?extension_data=. */
const TOOLSPY_CONVERTER_EXTENSION_DEFAULTS = {
  format: "webp",
  quality: 85,
};

function sanitizeFilenamePart(name, fallback) {
  const s = String(name || "")
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "_")
    .slice(0, 120);
  return s || fallback;
}

function guessExtFromUrl(url, contentType) {
  if (contentType && contentType.includes("/")) {
    const sub = contentType.split("/")[1];
    const clean = sub.split(";")[0].trim();
    if (clean && clean.length <= 5) return `.${clean}`;
  }
  try {
    const u = new URL(url);
    const m = u.pathname.match(/\.(jpe?g|png|gif|webp|bmp|svg|avif)$/i);
    if (m) return m[0].toLowerCase();
  } catch (_) {}
  return ".jpg";
}

async function fetchAsBlob(url) {
  const res = await fetch(url, { credentials: "omit", mode: "cors", cache: "no-store" });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const blob = await res.blob();
  return { blob, contentType: res.headers.get("content-type") || blob.type };
}

/**
 * Prefer ?extension_data= so searchParams work; fall back to #extension_data= when URL is too long.
 */
function buildExtensionDataUrl(baseOriginPath, encodedPayload) {
  const queryUrl = `${baseOriginPath}/?extension_data=${encodedPayload}`;
  const MAX_QUERY_CHARS = 8000;
  if (queryUrl.length <= MAX_QUERY_CHARS) return queryUrl;
  return `${baseOriginPath}/#extension_data=${encodedPayload}`;
}

async function buildZipFromUrls(urls) {
  const entries = Object.create(null);
  for (let i = 0; i < urls.length; i++) {
    const url = urls[i];
    let ext = ".jpg";
    let blob;
    try {
      const r = await fetchAsBlob(url);
      blob = r.blob;
      ext = guessExtFromUrl(url, r.contentType);
    } catch (e) {
      throw new Error(`Failed to fetch image ${i + 1}: ${e.message || e}`);
    }
    const buf = await blob.arrayBuffer();
    entries[`image-${i + 1}${ext}`] = new Uint8Array(buf);
  }
  return buildStoredZipBlob(entries);
}

/**
 * MV3 service workers: some Chromium builds (e.g. Opera) omit `URL.createObjectURL`.
 * Fall back to `webkitURL`, then data URL (very large ZIPs may hit URL size limits).
 */
function blobUrlForDownload(blob) {
  const U = globalThis.URL;
  if (U && typeof U.createObjectURL === "function") {
    const objectUrl = U.createObjectURL(blob);
    return Promise.resolve({
      url: objectUrl,
      revoke: () => {
        try {
          U.revokeObjectURL(objectUrl);
        } catch (_) {}
      },
    });
  }
  const W = globalThis.webkitURL;
  if (W && typeof W.createObjectURL === "function") {
    const objectUrl = W.createObjectURL(blob);
    return Promise.resolve({
      url: objectUrl,
      revoke: () => {
        try {
          W.revokeObjectURL(objectUrl);
        } catch (_) {}
      },
    });
  }
  return blobToDataUrl(blob).then((dataUrl) => ({
    url: dataUrl,
    revoke: () => {},
  }));
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onloadend = () => resolve(r.result);
    r.onerror = () => reject(r.error || new Error("FileReader failed"));
    r.readAsDataURL(blob);
  });
}

ext.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "BUILD_ZIP" && Array.isArray(msg.urls)) {
    buildZipFromUrls(msg.urls)
      .then((blob) => blobUrlForDownload(blob))
      .then(({ url, revoke }) => {
        const filename = sanitizeFilenamePart(msg.filename, "images") + ".zip";
        return ext.downloads
          .download({
            url,
            filename,
            saveAs: true,
          })
          .then(() => {
            setTimeout(revoke, 120000);
            sendResponse({ ok: true });
          });
      })
      .catch((err) => {
        sendResponse({ ok: false, error: err?.message || String(err) });
      });
    return true;
  }

  if (msg?.type === "DOWNLOAD_BLOB" && msg.blobUrl && msg.filename) {
    ext.downloads
      .download({
        url: msg.blobUrl,
        filename: sanitizeFilenamePart(msg.filename, "download"),
        saveAs: false,
      })
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
    return true;
  }

  if (msg?.type === "OPEN_TOOLSPY" && Array.isArray(msg.urls)) {
    const urls = msg.urls;
    const payload = {
      images: urls,
      settings: TOOLSPY_EXTENSION_DEFAULTS,
    };
    const encoded = encodeURIComponent(JSON.stringify(payload));
    const full = buildExtensionDataUrl(TOOLSPY_COMPRESSOR, encoded);
    if (full.length > 1_500_000) {
      sendResponse({
        ok: false,
        error:
          "Too many images to open in one step. Download or ZIP first, then use the compressor.",
      });
      return false;
    }
    ext.tabs.create({ url: full }).then(() => sendResponse({ ok: true })).catch((err) => {
      sendResponse({ ok: false, error: err?.message || String(err) });
    });
    return true;
  }

  if (msg?.type === "OPEN_TOOLSPY_CONVERTER" && Array.isArray(msg.urls)) {
    const urls = msg.urls;
    const payload = {
      images: urls,
      settings: TOOLSPY_CONVERTER_EXTENSION_DEFAULTS,
    };
    const encoded = encodeURIComponent(JSON.stringify(payload));
    const full = buildExtensionDataUrl(TOOLSPY_CONVERTER, encoded);
    if (full.length > 1_500_000) {
      sendResponse({
        ok: false,
        error:
          "Too many images to open in one step. Download or ZIP first, then use the converter.",
      });
      return false;
    }
    ext.tabs.create({ url: full }).then(() => sendResponse({ ok: true })).catch((err) => {
      sendResponse({ ok: false, error: err?.message || String(err) });
    });
    return true;
  }

  return false;
});
