# Image Downloader (Opera)

**Manifest V3** build (Chromium). Same code as `image-downloader-chrome`. ZIP downloads use `vendor/zip-store.js` and a `blobUrlForDownload` helper for service workers that lack `URL.createObjectURL`.

## Load unpacked

1. Open `opera://extensions`
2. Enable **Developer mode**
3. **Load unpacked** → select `extensions/image-downloader-opera`.

## Notes

- If the package is ever re-zipped for upload, keep `manifest.json` at the archive root.
