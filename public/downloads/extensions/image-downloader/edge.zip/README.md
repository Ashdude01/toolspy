# Image Downloader (Microsoft Edge)

Same **Manifest V3** Web Extension as `image-downloader-chrome`: scan the page for images, download selected files or a ZIP (STORE zip via `vendor/zip-store.js`), or open Toolspy Compressor / Converter.

## Load unpacked

1. Open `edge://extensions`
2. Enable **Developer mode**
3. **Load unpacked** → select `extensions/image-downloader-edge` (folder containing `manifest.json`).

Feature parity with `../image-downloader-chrome` and `../image-downloader-firefox`.
