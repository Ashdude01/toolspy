# Image Downloader (Firefox)

**Manifest V3** for Firefox: `background.scripts` loads `vendor/zip-store.js` then `background.js` (no `importScripts` required; the service-worker build also works if you only use the first script for the global `buildStoredZipBlob`).

- `browser_specific_settings.gecko.id`: `image-downloader@toolspy.net`
- `strict_min_version`: `140.0` (aligns with `data_collection_permissions` for AMO)

## Load temporary add-on

1. `about:debugging#/runtime/this-firefox`
2. **Load Temporary Add-on…**
3. Select `extensions/image-downloader-firefox/manifest.json`

## Notes

- Feature parity with `../image-downloader-chrome` (scan, download, ZIP, Toolspy links).
- ZIP is **uncompressed STORE** in `zip-store.js` (AMO-friendly, no third-party minified zip library).
