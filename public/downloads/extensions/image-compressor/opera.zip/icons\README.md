# Extension Icons

This folder should contain the following icon files for the Toolspy Image Compressor extension:

- `icon16.png` - 16x16 pixels (browser toolbar icon)
- `icon32.png` - 32x32 pixels (popup and context menus)
- `icon48.png` - 48x48 pixels (extension management page)
- `icon128.png` - 128x128 pixels (Chrome Web Store and extension detail page)

## Icon Design

The icons should represent the Toolspy brand with:
- Blue color scheme (#3b82f6 primary)
- Image compression/optimization theme
- Clean, modern design
- Proper transparency for different backgrounds

You can create these icons using the Toolspy logo and adding compression-related elements like:
- Compression arrows
- Image file icons
- Optimization symbols

For now, you can use placeholder icons or create simple colored squares with the Toolspy brand color until proper icons are designed. 