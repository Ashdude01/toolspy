// Toolspy Image Compressor - Enhanced Modern Popup Script
class ToolspyPopup {
  constructor() {
    this.detectedImages = [];
    this.selectedImageIds = new Set();
    this.currentTab = null;
    
    this.elements = {};
    this.settings = {
      preset: 'balanced',
      quality: 85,
      format: 'original',
      enableResize: false,
      resizeWidth: '',
      resizeHeight: '',
      maintainAspectRatio: true,
      removeExifData: true,
      enableProgressive: false,
      targetFileSize: '',
      darkMode: true // Default to dark mode
    };
    
    this.init();
  }

  async init() {
    try {
      this.bindElements();
      this.bindEvents();
      await this.getCurrentTab();
      await this.loadSettings();
      this.initializeTheme();
      this.initializePresets();
      await this.autoDetectImages();
    } catch (error) {
      console.error('Failed to initialize popup:', error);
      if (error.message.includes('Extension context invalidated')) {
        this.showToast('Extension was reloaded. Please close and reopen this popup.', 'error');
      } else {
        this.showToast('Failed to initialize extension. Please try reloading.', 'error');
      }
    }
  }
  
  initializePresets() {
    // Apply the default preset selection on load
    if (this.settings.preset) {
      this.updatePresetSelection(this.settings.preset);
    } else {
      // Default to balanced preset
      this.applyPreset('balanced');
    }
  }

  bindElements() {
    // Status elements
    this.elements.imageCount = document.getElementById('imageCount');
    this.elements.selectedCount = document.getElementById('selectedCount');
    this.elements.refreshBtn = document.getElementById('refreshBtn');
    
    // Theme toggle
    this.elements.themeToggle = document.getElementById('themeToggle');
    this.elements.darkIcon = document.getElementById('darkIcon');
    this.elements.lightIcon = document.getElementById('lightIcon');
    
    // Loading and sections
    this.elements.loadingState = document.getElementById('loadingState');
    this.elements.imagesSection = document.getElementById('imagesSection');
    this.elements.imagesGrid = document.getElementById('imagesGrid');
    
    // Selection buttons
    this.elements.selectAllBtn = document.getElementById('selectAllBtn');
    this.elements.clearAllBtn = document.getElementById('clearAllBtn');
    
    // Settings elements
    this.elements.presetCards = document.querySelectorAll('.preset-card');
    this.elements.qualitySlider = document.getElementById('qualitySlider');
    this.elements.qualityValue = document.getElementById('qualityValue');
    this.elements.formatSelect = document.getElementById('formatSelect');
    this.elements.toggleAdvanced = document.getElementById('toggleAdvanced');
    this.elements.advancedSettings = document.getElementById('advancedSettings');
    this.elements.enableResize = document.getElementById('enableResize');
    this.elements.resizeOptions = document.getElementById('resizeOptions');
    this.elements.resizeWidth = document.getElementById('resizeWidth');
    this.elements.resizeHeight = document.getElementById('resizeHeight');
    this.elements.maintainAspectRatio = document.getElementById('maintainAspectRatio');
    this.elements.removeExifData = document.getElementById('removeExifData');
    this.elements.enableProgressive = document.getElementById('enableProgressive');
    this.elements.targetFileSize = document.getElementById('targetFileSize');
    
    // Action elements
    this.elements.compressBtn = document.getElementById('compressBtn');
  }

  bindEvents() {
    // Theme toggle
    this.elements.themeToggle.addEventListener('click', () => this.toggleTheme());
    
    // Basic controls
    this.elements.refreshBtn.addEventListener('click', () => this.refreshImages());
    this.elements.selectAllBtn.addEventListener('click', () => this.selectAllImages());
    this.elements.clearAllBtn.addEventListener('click', () => this.clearSelection());
    
    // Preset cards
    this.elements.presetCards.forEach(card => {
      card.addEventListener('click', () => {
        const preset = card.dataset.preset;
        this.applyPreset(preset);
        this.updatePresetSelection(preset);
      });
    });
    
    // Settings events
    this.elements.qualitySlider.addEventListener('input', (e) => this.updateQuality(e.target.value));
    this.elements.formatSelect.addEventListener('change', (e) => this.updateSetting('format', e.target.value));
    this.elements.toggleAdvanced.addEventListener('click', () => this.toggleAdvancedSettings());
    this.elements.enableResize.addEventListener('change', (e) => this.toggleResize(e.target.checked));
    this.elements.resizeWidth.addEventListener('input', (e) => this.updateSetting('resizeWidth', e.target.value));
    this.elements.resizeHeight.addEventListener('input', (e) => this.updateSetting('resizeHeight', e.target.value));
    this.elements.maintainAspectRatio.addEventListener('change', (e) => this.updateSetting('maintainAspectRatio', e.target.checked));
    this.elements.removeExifData.addEventListener('change', (e) => this.updateSetting('removeExifData', e.target.checked));
    this.elements.enableProgressive.addEventListener('change', (e) => this.updateSetting('enableProgressive', e.target.checked));
    this.elements.targetFileSize.addEventListener('input', (e) => this.updateSetting('targetFileSize', e.target.value));
    
    // Action events
    this.elements.compressBtn.addEventListener('click', () => this.redirectToToolspy());
    
    // Listen for messages from content script
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === 'imagesDetected') {
        this.updateImageCount(request.count);
      }
    });
  }

  // Theme Management
  initializeTheme() {
    this.applyTheme(this.settings.darkMode);
  }

  toggleTheme() {
    this.settings.darkMode = !this.settings.darkMode;
    this.applyTheme(this.settings.darkMode);
    this.saveSettings();
  }

  applyTheme(isDark) {
    const body = document.body;
    if (isDark) {
      body.classList.add('dark');
      this.elements.darkIcon.classList.remove('hidden');
      this.elements.lightIcon.classList.add('hidden');
    } else {
      body.classList.remove('dark');
      this.elements.darkIcon.classList.add('hidden');
      this.elements.lightIcon.classList.remove('hidden');
    }
  }

  async getCurrentTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    this.currentTab = tabs[0];
    
    console.log('Current tab:', this.currentTab?.url);
    
    // Check if this is a valid tab for content script injection
    if (this.currentTab && !this.isValidTabForContentScript(this.currentTab.url)) {
      console.warn('Content script cannot be injected on this page:', this.currentTab.url);
    }
  }

  isValidTabForContentScript(url) {
    if (!url) return false;
    
    // Pages where content scripts cannot be injected
    const invalidProtocols = ['chrome:', 'chrome-extension:', 'moz-extension:', 'about:', 'edge:', 'opera:'];
    const invalidDomains = ['chrome.google.com/webstore'];
    
    for (const protocol of invalidProtocols) {
      if (url.startsWith(protocol)) return false;
    }
    
    for (const domain of invalidDomains) {
      if (url.includes(domain)) return false;
    }
    
    return url.startsWith('http://') || url.startsWith('https://');
  }

  async autoDetectImages() {
    this.showLoading();
    try {
      // First test basic connectivity
      const isConnected = await this.testContentScriptConnection();
      if (!isConnected) {
        this.hideLoading();
        this.showToast('Cannot access this page. Try refreshing and reopening the extension.', 'error');
        return;
      }
      
      await this.refreshImages();
    } catch (error) {
      console.error('Failed to auto-detect images:', error);
      this.hideLoading();
      this.showToast('Failed to detect images on this page', 'error');
    }
  }

  async testContentScriptConnection() {
    try {
      console.log('Testing content script connection...');
      const response = await this.sendMessageToContentScript({ action: 'ping' }, 1);
      console.log('Content script connection test result:', response);
      return response && response.pong === true;
    } catch (error) {
      console.error('Content script connection test failed:', error);
      return false;
    }
  }

  async refreshImages() {
    if (!this.currentTab) return;
    
    this.showLoading();
    
    try {
      // Check if the current tab is valid for content script injection
      if (!this.isValidTabForContentScript(this.currentTab.url)) {
        this.hideLoading();
        this.updateImageCount(0);
        this.showToast('This extension cannot scan images on this type of page. Please navigate to a regular website.', 'error');
        return;
      }

      // Try to communicate with content script
      const response = await this.sendMessageToContentScript({ action: 'getImages' });
      
      this.detectedImages = response.images || [];
      this.updateImageCount(response.count || 0);
      this.renderImagesGrid();
      this.hideLoading();
      
      if (this.detectedImages.length > 0) {
        this.showImagesSection();
      } else {
        this.hideImagesSection();
        this.showToast('No images found on this page', 'info');
      }
    } catch (error) {
      console.error('Failed to get images:', error);
      this.hideLoading();
      this.updateImageCount(0);
      
      if (error.message.includes('content script')) {
        this.showToast('Unable to access this page. Try refreshing the page and reopening the extension.', 'error');
      } else {
        this.showToast('Unable to scan this page for images', 'error');
      }
    }
  }

  async sendMessageToContentScript(message, maxRetries = 3) {
    console.log('Sending message to content script:', message);
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        console.log(`Attempt ${attempt}/${maxRetries} to communicate with content script`);
        
        // Check if tab is valid
        if (!this.currentTab || !this.currentTab.id) {
          throw new Error('No valid tab selected');
        }
        
        // Check if tab is still valid
        const tab = await chrome.tabs.get(this.currentTab.id);
        if (!tab || tab.status !== 'complete') {
          throw new Error('Tab is not ready');
        }
        
        // Try to send message
        const response = await chrome.tabs.sendMessage(this.currentTab.id, message);
        console.log('Content script responded:', response);
        
        if (response && (response.pong || response.images !== undefined || response.files !== undefined)) {
          return response;
        } else {
          throw new Error('Invalid response from content script');
        }
        
      } catch (error) {
        console.warn(`Attempt ${attempt} failed:`, error.message);
        
        if (attempt === maxRetries) {
          throw new Error(`Failed to communicate with content script after ${maxRetries} attempts: ${error.message}`);
        }
        
        // Try to inject content script on failed attempts
        if (attempt < maxRetries) {
          try {
            console.log('Attempting to inject content script...');
            
            // First inject CSS
            await chrome.scripting.insertCSS({
              target: { tabId: this.currentTab.id },
              files: ['content.css']
            });
            
            // Then inject JavaScript
            await chrome.scripting.executeScript({
              target: { tabId: this.currentTab.id },
              files: ['content.js']
            });
            
            console.log('Content script injected, waiting...');
            await new Promise(resolve => setTimeout(resolve, 2000));
          } catch (injectError) {
            console.error('Failed to inject content script:', injectError);
            if (injectError.message.includes('Cannot access')) {
              throw new Error('Cannot inject content script on this page. This extension only works on regular websites.');
            }
          }
        }
      }
    }
  }

  showLoading() {
    this.elements.loadingState.classList.remove('hidden');
    this.elements.imageCount.textContent = 'Scanning...';
  }

  hideLoading() {
    this.elements.loadingState.classList.add('hidden');
  }

  showImagesSection() {
    this.elements.imagesSection.classList.remove('hidden');
  }

  hideImagesSection() {
    this.elements.imagesSection.classList.add('hidden');
  }

  updateImageCount(count) {
    this.elements.imageCount.textContent = count.toString();
    this.elements.refreshBtn.disabled = false;
  }

  renderImagesGrid() {
    this.elements.imagesGrid.innerHTML = '';
    
    this.detectedImages.forEach((image) => {
      const imageItem = this.createImageItem(image);
      this.elements.imagesGrid.appendChild(imageItem);
    });
  }

  createImageItem(image) {
    const item = document.createElement('div');
    item.className = 'image-item';
    item.dataset.imageId = image.id;
    
    // Create thumbnail
    const thumbnail = document.createElement('img');
    thumbnail.className = 'image-thumbnail';
    thumbnail.src = image.src;
    thumbnail.alt = image.alt;
    thumbnail.loading = 'lazy';
    
    // Handle image load errors
    thumbnail.onerror = () => {
      thumbnail.style.background = 'var(--muted)';
      thumbnail.alt = 'Failed to load';
    };
    
    // Create info section
    const info = document.createElement('div');
    info.className = 'image-info';
    
    const name = document.createElement('div');
    name.className = 'image-name';
    name.textContent = this.getImageName(image.src);
    
    const size = document.createElement('div');
    size.className = 'image-size';
    size.textContent = `${image.width}×${image.height}`;
    
    info.appendChild(name);
    info.appendChild(size);
    
    // Create selection badge
    const badge = document.createElement('div');
    badge.className = 'image-select-badge';
    badge.textContent = '+';
    
    // Assemble item
    item.appendChild(thumbnail);
    item.appendChild(info);
    item.appendChild(badge);
    
    // Add click handler
    item.addEventListener('click', () => this.toggleImageSelection(image.id));
    
    return item;
  }

  getImageName(src) {
    try {
      const url = new URL(src);
      const pathname = url.pathname;
      const filename = pathname.split('/').pop() || 'image';
      return filename.length > 15 ? filename.substring(0, 12) + '...' : filename;
    } catch {
      return 'image';
    }
  }

  toggleImageSelection(imageId) {
    const item = document.querySelector(`[data-image-id="${imageId}"]`);
    const badge = item.querySelector('.image-select-badge');
    
    if (this.selectedImageIds.has(imageId)) {
      this.selectedImageIds.delete(imageId);
      item.classList.remove('selected');
      badge.textContent = '+';
    } else {
      this.selectedImageIds.add(imageId);
      item.classList.add('selected');
      badge.textContent = '✓';
    }
    
    this.updateSelectionCount();
  }

  selectAllImages() {
    this.detectedImages.forEach(image => {
      this.selectedImageIds.add(image.id);
      const item = document.querySelector(`[data-image-id="${image.id}"]`);
      if (item) {
        const badge = item.querySelector('.image-select-badge');
        item.classList.add('selected');
        badge.textContent = '✓';
      }
    });
    
    this.updateSelectionCount();
    this.showToast('All images selected', 'success');
  }

  clearSelection() {
    this.selectedImageIds.clear();
    
    document.querySelectorAll('.image-item').forEach(item => {
      const badge = item.querySelector('.image-select-badge');
      item.classList.remove('selected');
      badge.textContent = '+';
    });
    
    this.updateSelectionCount();
    this.showToast('Selection cleared', 'info');
  }

  updateSelectionCount() {
    const count = this.selectedImageIds.size;
    this.elements.selectedCount.textContent = count.toString();
    
    // Update button states
    this.elements.compressBtn.disabled = count === 0;
    
    const btnText = this.elements.compressBtn.querySelector('.btn-text');
    if (count > 0) {
      btnText.textContent = `Compress ${count} Image${count > 1 ? 's' : ''}`;
      this.elements.compressBtn.classList.remove('btn-primary');
      this.elements.compressBtn.classList.add('btn-primary');
    } else {
      btnText.textContent = 'Select images to compress';
    }
  }

  // Preset Management
  updatePresetSelection(selectedPreset) {
    this.elements.presetCards.forEach(card => {
      if (card.dataset.preset === selectedPreset) {
        card.classList.add('active');
      } else {
        card.classList.remove('active');
      }
    });
  }

  applyPreset(preset) {
    this.settings.preset = preset;
    
    // Preset configurations
    const presetConfigs = {
      'balanced': { quality: 85, format: 'original' },
      'high-quality': { quality: 95, format: 'original' },
      'max-compression': { quality: 60, format: 'webp' },
      'web-optimized': { quality: 80, format: 'webp' }
    };
    
    const presetConfig = presetConfigs[preset];
    
    if (!presetConfig) {
      console.error(`Unknown preset: ${preset}`);
      return;
    }
    
    this.settings.quality = presetConfig.quality;
    this.settings.format = presetConfig.format;
    
    // Update UI
    this.elements.qualitySlider.value = presetConfig.quality;
    this.elements.qualityValue.textContent = presetConfig.quality;
    this.elements.formatSelect.value = presetConfig.format;
    
    this.updatePresetSelection(preset);
    this.saveSettings();
  }

  updateQuality(quality) {
    this.settings.quality = parseInt(quality);
    this.elements.qualityValue.textContent = quality;
    
    // Update preset selection based on quality
    const presetConfigs = {
      'balanced': { quality: 85 },
      'high-quality': { quality: 95 },
      'max-compression': { quality: 60 },
      'web-optimized': { quality: 80 }
    };
    
    let closestPreset = 'balanced';
    let minDiff = Infinity;
    
    Object.entries(presetConfigs).forEach(([presetName, config]) => {
      const diff = Math.abs(config.quality - parseInt(quality));
      if (diff < minDiff) {
        minDiff = diff;
        closestPreset = presetName;
      }
    });
    
    if (minDiff <= 5) { // Only auto-select if very close
      this.settings.preset = closestPreset;
      this.updatePresetSelection(closestPreset);
    } else {
      // Clear preset selection if custom quality
      this.elements.presetCards.forEach(card => card.classList.remove('active'));
    }
    
    this.saveSettings();
  }

  updateSetting(key, value) {
    this.settings[key] = value;
    this.saveSettings();
  }

  toggleResize(enabled) {
    this.settings.enableResize = enabled;
    this.elements.resizeOptions.classList.toggle('hidden', !enabled);
    this.saveSettings();
  }

  toggleAdvancedSettings() {
    const isHidden = this.elements.advancedSettings.classList.contains('hidden');
    this.elements.advancedSettings.classList.toggle('hidden', !isHidden);
    
    const arrow = this.elements.toggleAdvanced.querySelector('svg');
    arrow.style.transform = isHidden ? 'rotate(180deg)' : 'rotate(0deg)';
  }

  async redirectToToolspy() {
    if (this.selectedImageIds.size === 0) {
      this.showToast('Please select images to compress', 'error');
      return;
    }

    try {
      // Get selected images from detectedImages array
      const selectedImages = this.detectedImages.filter(img => 
        img && img.id && this.selectedImageIds.has(img.id)
      );

      if (selectedImages.length === 0) {
        this.showToast('No valid images selected. Please refresh and try again.', 'error');
        return;
      }

      // Extract only image URLs
      const imageUrls = selectedImages
        .map(img => img.src)
        .filter(url => url && url.trim() !== '');

      if (imageUrls.length === 0) {
        this.showToast('Selected images have no valid URLs.', 'error');
        return;
      }

      // Prepare compression settings
      const compressionSettings = {
        preset: this.settings.preset || 'balanced',
        quality: typeof this.settings.quality === 'number' ? this.settings.quality : 85,
        format: this.settings.format || 'original',
        resize: this.settings.enableResize ? {
          width: this.settings.resizeWidth ? parseInt(this.settings.resizeWidth) : undefined,
          height: this.settings.resizeHeight ? parseInt(this.settings.resizeHeight) : undefined,
          maintainAspectRatio: this.settings.maintainAspectRatio !== false
        } : undefined,
        removeExifData: this.settings.removeExifData !== false,
        enableProgressive: this.settings.enableProgressive === true,
        targetFileSize: this.settings.targetFileSize ? parseInt(this.settings.targetFileSize) : undefined
      };
      
      // Validate compression settings
      if (compressionSettings.quality < 1 || compressionSettings.quality > 100) {
        compressionSettings.quality = 85;
      }

      // Create the data array with only image URLs
      const dataToSend = {
        images: imageUrls,
        settings: compressionSettings
      };

      console.log('Prepared data for redirect:', {
        imageCount: imageUrls.length,
        imageUrls: imageUrls,
        settings: compressionSettings
      });
      
      // Stringify and URL encode the data
      const jsonString = JSON.stringify(dataToSend);
      
      // Build URL with extension_data parameter
      const redirectUrl = `https://toolspy.net/image-compressor?extension_data=${encodeURIComponent(jsonString)}`;
      
      // Open in new tab
      chrome.tabs.create({ url: redirectUrl });
      
      this.showToast(`Redirecting ${imageUrls.length} image(s) to Toolspy...`, 'success');

    } catch (error) {
      console.error('Failed to prepare images:', error);
      
      if (error.message.includes('content script') || error.message.includes('Cannot access this page')) {
        this.showToast('Cannot access page content. Try refreshing the page and reopening the extension.', 'error');
      } else if (error.message.includes('No matching images')) {
        this.showToast('Selected images are no longer available. Please refresh the page and try again.', 'error');
      } else {
        this.showToast('Failed to prepare images: ' + error.message, 'error');
      }
    }
  }

  showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;

    document.getElementById('toastContainer').appendChild(toast);

    // Auto remove after 4 seconds
    setTimeout(() => {
      toast.remove();
    }, 4000);
  }

  saveSettings() {
    chrome.storage.local.set({ toolspySettings: this.settings });
  }

  async loadSettings() {
    try {
      const result = await chrome.storage.local.get('toolspySettings');
      if (result.toolspySettings) {
        this.settings = { ...this.settings, ...result.toolspySettings };
        this.applySettingsToUI();
      }
    } catch (error) {
      console.error('Failed to load settings:', error);
    }
  }

  applySettingsToUI() {
    // Apply preset selection
    this.updatePresetSelection(this.settings.preset);
    
    // Apply other settings
    this.elements.qualitySlider.value = this.settings.quality;
    this.elements.qualityValue.textContent = this.settings.quality;
    this.elements.formatSelect.value = this.settings.format;
    this.elements.enableResize.checked = this.settings.enableResize;
    this.elements.resizeWidth.value = this.settings.resizeWidth;
    this.elements.resizeHeight.value = this.settings.resizeHeight;
    this.elements.maintainAspectRatio.checked = this.settings.maintainAspectRatio;
    this.elements.removeExifData.checked = this.settings.removeExifData;
    this.elements.enableProgressive.checked = this.settings.enableProgressive;
    this.elements.targetFileSize.value = this.settings.targetFileSize;

    // Update UI state
    this.elements.resizeOptions.classList.toggle('hidden', !this.settings.enableResize);
  }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new ToolspyPopup();
}); 