# 🔧 Extension Debugging Guide

## Current Error: "Cannot read properties of undefined (reading 'length')"

### Quick Fix Steps:

1. **Open Chrome DevTools** (F12)
2. **Go to Console tab**
3. **Load the extension** and try to compress images
4. **Look for these specific debug messages:**

```
✅ Expected successful flow:
- "Toolspy content script initialized"
- "Extension popup initialized"
- "X images detected successfully"
- "Content script communication successful"
- "Starting compression with settings: {...}"
- "Processing file 1/X: filename.jpg (12345 bytes)"
- "Successfully compressed filename.jpg: 12345 -> 6789 bytes"

❌ Error indicators:
- "No files provided to batchCompress"
- "Invalid file object provided"
- "File has no type property"
- "No matching images found"
- "Content script response: undefined"
```

### Common Issues & Solutions:

#### 1. **Content Script Not Loading**
**Symptoms:** No images detected, communication fails
**Solution:**
```javascript
// Check if content script is loaded
chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
  chrome.tabs.sendMessage(tabs[0].id, {action: 'ping'}, (response) => {
    console.log('Content script ping result:', response);
  });
});
```

#### 2. **File Objects Invalid**
**Symptoms:** "Invalid file object provided"
**Debug:** Check what files are being passed:
```javascript
console.log('Files being processed:', response.files);
response.files.forEach((file, i) => {
  console.log(`File ${i}:`, {
    name: file.name,
    size: file.size,
    type: file.type,
    valid: file && file.name && file.size && file.type
  });
});
```

#### 3. **Image Selection Issues**
**Symptoms:** "No matching images found"
**Debug:** 
```javascript
// In popup.js, check selected IDs vs available images
console.log('Selected IDs:', Array.from(this.selectedImageIds));
console.log('Available images:', this.detectedImages.map(img => ({id: img.id, src: img.src})));
```

### Step-by-Step Debugging:

#### Phase 1: Extension Loading
```
1. Load extension → Check for console errors
2. Open popup → Should see "Extension popup initialized"
3. Check current tab → Should see detected image count
```

#### Phase 2: Image Detection
```
1. Click refresh → Should see "X images detected"
2. Images should appear in grid
3. Check console for "Content script communication successful"
```

#### Phase 3: Selection & Compression
```
1. Select images → Check selectedImageIds.size > 0
2. Click compress → Should see compression progress
3. Monitor console for file processing logs
```

### Debug Test Page:

Use `debug-test.html` for simplified testing:
- Only 3 simple images
- Enhanced console logging
- Step-by-step debug info

### Error Recovery:

If extension fails:
1. **Reload extension** in chrome://extensions/
2. **Refresh the webpage**
3. **Reopen extension popup**
4. **Check console for new errors**

### Advanced Debugging:

#### Check File Object Structure:
```javascript
// In content.js imageToFile function
console.log('Creating file from image:', {
  src: imageData.src,
  type: imageData.type,
  width: width,
  height: height
});

// After blob creation
console.log('Blob created:', {
  size: blob.size,
  type: blob.type
});

// After File creation
console.log('File object:', {
  name: file.name,
  size: file.size,
  type: file.type,
  lastModified: file.lastModified
});
```

#### Validate Compression Settings:
```javascript
// In popup.js before compression
console.log('Compression settings:', compressionSettings);
console.log('Settings validation:', {
  quality: typeof compressionSettings.quality,
  format: compressionSettings.format,
  valid: compressionSettings.quality >= 1 && compressionSettings.quality <= 100
});
```

### Known Working Flow:

```
1. Page loads → Content script initializes
2. Popup opens → Detects images via content script
3. User selects images → IDs stored in selectedImageIds Set
4. User clicks compress → getImageFiles called with IDs
5. Content script converts images to File objects
6. Files passed to compression engine
7. Each file processed individually
8. Results returned and displayed
```

### Emergency Reset:

If completely broken:
1. **Disable extension**
2. **Clear browser cache**
3. **Reload extension**
4. **Test on simple page** (debug-test.html)
5. **Check all console messages**

---

*Use this guide to systematically identify where the compression process is failing.*