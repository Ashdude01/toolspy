// Toolspy Image Compressor - Enhanced Content Script
class ToolspyContentScript {
  constructor() {
    this.detectedImages = [];
    this.imageIndex = 0;
    this.setupMessageListener();
    this.init();
  }

  init() {
    // Initial detection
    this.detectImages();
    
    // Watch for new images
    this.setupMutationObserver();
    
    // Detect on scroll for lazy-loaded images
    this.setupScrollListener();
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      console.log('Content script received message:', request);
      
      if (request.action === 'ping') {
        console.log('Ping received, responding with pong');
        sendResponse({ pong: true, timestamp: Date.now() });
        return false; // Synchronous response
      } else if (request.action === 'getImages') {
        sendResponse({
          images: this.detectedImages,
          count: this.detectedImages.length
        });
        return false; // Synchronous response
      } else if (request.action === 'getImageFiles') {
        // Handle async operation properly with better error handling
        (async () => {
          try {
            console.log('Processing getImageFiles request for IDs:', request.imageIds);
            
            // Validate input
            if (!request.imageIds || !Array.isArray(request.imageIds) || request.imageIds.length === 0) {
              throw new Error('Invalid image IDs provided');
            }
            
            const files = await this.getImageFiles(request.imageIds);
            console.log('Sending files response:', files.length, 'files');
            
            // Convert File objects to serializable format
            const serializedFiles = await Promise.all(
              files.map(async (file) => {
                const arrayBuffer = await file.arrayBuffer();
                return {
                  name: file.name,
                  type: file.type,
                  size: file.size,
                  lastModified: file.lastModified,
                  data: Array.from(new Uint8Array(arrayBuffer)) // Convert to regular array for JSON serialization
                };
              })
            );
            
            sendResponse({ files: serializedFiles, success: true });
          } catch (error) {
            console.error('Error getting image files:', error);
            sendResponse({ files: [], success: false, error: error.message });
          }
        })();
        return true; // Keep message channel open for async response
      }
      return false;
    });
  }

  detectImages() {
    this.detectedImages = [];
    this.imageIndex = 0;

    // Detect regular img elements
    this.detectRegularImages();
    
    // Detect background images
    this.detectBackgroundImages();

    console.log(`Detected ${this.detectedImages.length} images`);
    
    // Notify popup about image count
    chrome.runtime.sendMessage({
      action: 'imagesDetected',
      count: this.detectedImages.length
    }).catch(() => {
      // Ignore errors if popup is not open
    });
  }

  detectRegularImages() {
    const images = document.querySelectorAll('img');
    
    images.forEach(img => {
      // Use currentSrc for responsive images, fallback to src
      const imageSrc = img.currentSrc || img.src || img.getAttribute('src');
      
      if (!imageSrc || imageSrc.trim() === '') {
        return;
      }
      
      // Skip data URLs (except for base64 images we want to include)
      if (imageSrc.startsWith('data:image/svg')) {
        return;
      }
      
      // Skip placeholder images
      if (imageSrc.includes('placeholder') || imageSrc.includes('1x1') || imageSrc.includes('blank')) {
        return;
      }
      
      // Resolve relative URLs to absolute
      let absoluteSrc = imageSrc;
      try {
        if (imageSrc.startsWith('//')) {
          absoluteSrc = window.location.protocol + imageSrc;
        } else if (imageSrc.startsWith('/')) {
          absoluteSrc = window.location.origin + imageSrc;
        } else if (!imageSrc.startsWith('http') && !imageSrc.startsWith('data:')) {
          absoluteSrc = new URL(imageSrc, window.location.href).href;
        }
      } catch (e) {
        console.warn('Failed to resolve image URL:', imageSrc, e);
        return;
      }
      
      // Get dimensions - use natural dimensions if available, otherwise use display dimensions
      const width = img.naturalWidth || img.width || img.offsetWidth || 0;
      const height = img.naturalHeight || img.height || img.offsetHeight || 0;
      
      // Only filter out very small images (likely icons/spacers) - reduce threshold to 20px
      const minSize = 20;
      if (width > 0 && height > 0 && width < minSize && height < minSize) {
        return;
      }
      
      const imageData = {
        id: `img-${this.imageIndex++}`,
        src: absoluteSrc,
        alt: img.alt || img.title || 'Image',
        width: width || 0,
        height: height || 0,
        element: img,
        type: this.getImageType(absoluteSrc),
        isBackground: false
      };
      
      this.detectedImages.push(imageData);
      img.setAttribute('data-toolspy-id', imageData.id);
    });
    
    // Also detect images in <picture> and <source> elements
    const pictureElements = document.querySelectorAll('picture source[srcset]');
    pictureElements.forEach(source => {
      const srcset = source.getAttribute('srcset');
      if (srcset) {
        // Parse srcset to get image URLs
        const urls = srcset.split(',').map(item => {
          const parts = item.trim().split(/\s+/);
          return parts[0];
        });
        
        urls.forEach(url => {
          if (url && !url.startsWith('data:image/svg') && !this.detectedImages.find(img => img.src === url)) {
            try {
              let absoluteUrl = url;
              if (url.startsWith('//')) {
                absoluteUrl = window.location.protocol + url;
              } else if (url.startsWith('/')) {
                absoluteUrl = window.location.origin + url;
              } else if (!url.startsWith('http') && !url.startsWith('data:')) {
                absoluteUrl = new URL(url, window.location.href).href;
              }
              
              const imageData = {
                id: `src-${this.imageIndex++}`,
                src: absoluteUrl,
                alt: 'Source Image',
                width: 0,
                height: 0,
                element: source,
                type: this.getImageType(absoluteUrl),
                isBackground: false
              };
              
              this.detectedImages.push(imageData);
            } catch (e) {
              console.warn('Failed to process source image URL:', url, e);
            }
          }
        });
      }
    });
  }

  detectBackgroundImages() {
    const elements = document.querySelectorAll('*');
    
    elements.forEach(element => {
      try {
        const style = window.getComputedStyle(element);
        const backgroundImage = style.backgroundImage;
        
        if (backgroundImage && backgroundImage !== 'none' && backgroundImage !== 'initial' && backgroundImage !== 'inherit') {
          // Match multiple URL patterns: url("..."), url('...'), url(...), url("...") url("...")
          const urlMatches = backgroundImage.match(/url\(["']?([^"')]+)["']?\)/g);
          
          if (urlMatches && urlMatches.length > 0) {
            urlMatches.forEach(urlMatch => {
              const urlContent = urlMatch.match(/url\(["']?([^"')]+)["']?\)/);
              if (urlContent && urlContent[1]) {
                let src = urlContent[1].trim();
                
                // Skip data URLs (except base64 images)
                if (src.startsWith('data:image/svg')) {
                  return;
                }
                
                // Skip placeholder images
                if (src.includes('placeholder') || src.includes('1x1') || src.includes('blank')) {
                  return;
                }
                
                // Resolve relative URLs
                try {
                  if (src.startsWith('//')) {
                    src = window.location.protocol + src;
                  } else if (src.startsWith('/')) {
                    src = window.location.origin + src;
                  } else if (!src.startsWith('http') && !src.startsWith('data:')) {
                    src = new URL(src, window.location.href).href;
                  }
                } catch (e) {
                  console.warn('Failed to resolve background image URL:', src, e);
                  return;
                }
                
                // Check if already detected
                if (!this.detectedImages.find(img => img.src === src)) {
                  const width = element.offsetWidth || element.clientWidth || 0;
                  const height = element.offsetHeight || element.clientHeight || 0;
                  
                  // Only include if element has reasonable size
                  if (width > 20 && height > 20) {
                    const imageData = {
                      id: `bg-${this.imageIndex++}`,
                      src: src,
                      alt: 'Background Image',
                      width: width,
                      height: height,
                      element: element,
                      type: this.getImageType(src),
                      isBackground: true
                    };
                    
                    this.detectedImages.push(imageData);
                    element.setAttribute('data-toolspy-bg-id', imageData.id);
                  }
                }
              }
            });
          }
        }
      } catch (e) {
        // Skip elements that cause errors
        console.warn('Error detecting background image:', e);
      }
    });
  }


  getImageType(src) {
    const extension = src.split('.').pop()?.split('?')[0]?.toLowerCase();
    const typeMap = {
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'gif': 'image/gif',
      'webp': 'image/webp',
      'bmp': 'image/bmp',
      'tiff': 'image/tiff',
      'svg': 'image/svg+xml'
    };
    return typeMap[extension] || 'image/jpeg';
  }

  async getImageFiles(imageIds) {
    console.log('getImageFiles called with IDs:', imageIds);
    
    if (!imageIds || !Array.isArray(imageIds) || imageIds.length === 0) {
      throw new Error('No valid image IDs provided');
    }

    console.log('Detected images available:', this.detectedImages.length);
    console.log('Looking for IDs:', imageIds);

    const selectedImageData = this.detectedImages.filter(img => 
      img && img.id && imageIds.includes(img.id)
    );
    
    console.log('Selected image data:', selectedImageData.length, 'out of', imageIds.length);
    
    if (selectedImageData.length === 0) {
      const availableIds = this.detectedImages.map(img => img?.id).filter(Boolean);
      console.error('No matching images found. Available IDs:', availableIds);
      throw new Error(`No matching images found for the provided IDs. Available: ${availableIds.length}, Requested: ${imageIds.length}`);
    }

    const files = [];
    const failedImages = [];
    const corsRestrictedImages = [];
    
    // Process images with better error tracking
    for (let i = 0; i < selectedImageData.length; i++) {
      const imageData = selectedImageData[i];
      try {
        console.log(`Processing image ${i + 1}/${selectedImageData.length}: ${imageData.src}`);
        const file = await this.imageToFile(imageData);
        if (file && file.size > 0) {
          files.push(file);
          console.log('Successfully converted image to file:', file.name, `(${file.size} bytes)`);
        } else {
          throw new Error('Generated file is empty or invalid');
        }
      } catch (error) {
        console.error(`Failed to convert image ${i + 1} to file:`, imageData.src, error.message);
        
        // Categorize CORS-related errors separately
        if (error.message.includes('CORS') || 
            error.message.includes('Tainted canvases') || 
            error.message.includes('cross-origin') ||
            error.message.includes('Cannot read cross-origin')) {
          corsRestrictedImages.push({
            src: imageData.src,
            error: 'CORS restricted'
          });
        } else {
          failedImages.push({
            src: imageData.src,
            error: error.message
          });
        }
        // Continue with other images even if one fails
      }
    }
    
    console.log(`Conversion complete: ${files.length} successful, ${failedImages.length} failed, ${corsRestrictedImages.length} CORS-restricted`);
    
    if (files.length === 0) {
      if (corsRestrictedImages.length > 0) {
        throw new Error(`All selected images are from external sources and cannot be processed due to CORS restrictions. These images come from different domains that don't allow cross-origin access. To compress these images, try:\n\n• Right-click and "Save image as..." to your computer first\n• Select images from the same website you're currently on\n• Use the main Toolspy website (toolspy.com) to upload and compress images`);
      }
      
      const errorDetails = failedImages.length > 0 
        ? `All images failed to load. Common issues: ${failedImages[0].error}` 
        : 'No images could be processed';
      throw new Error(`${errorDetails}. Try refreshing the page and selecting different images.`);
    }
    
    if (corsRestrictedImages.length > 0 || failedImages.length > 0) {
      const totalFailed = corsRestrictedImages.length + failedImages.length;
      console.warn(`${totalFailed} images failed to convert - ${corsRestrictedImages.length} CORS-restricted, ${failedImages.length} other errors`);
      
      // Add metadata about failed images to help popup show better messages
      if (corsRestrictedImages.length > 0) {
        window.toolspyCorsRestrictedCount = corsRestrictedImages.length;
      }
    }
    
    return files;
  }

  async imageToFile(imageData) {
    try {
      console.log(`Converting image to file: ${imageData.src}`);
      
      // Try fetch approach first for better CORS handling
      try {
        const blob = await this.fetchImageAsBlob(imageData.src);
        if (blob && blob.size > 0) {
          console.log(`Fetched image directly as blob: ${blob.size} bytes`);
          
          const filename = this.generateFilename(imageData.src, imageData.type);
          const file = new File([blob], filename, { 
            type: imageData.type || blob.type || 'image/jpeg',
            lastModified: Date.now()
          });
          
          console.log(`File created from fetch: ${file.name} (${file.size} bytes, type: ${file.type})`);
          return file;
        }
      } catch (fetchError) {
        console.warn(`Fetch approach failed for ${imageData.src}: ${fetchError.message}, trying canvas approach`);
      }
      
      // Fallback to canvas approach if fetch fails
      const img = await this.loadImage(imageData.src);
      
      // Validate image dimensions
      const width = img.naturalWidth || img.width || 0;
      const height = img.naturalHeight || img.height || 0;
      
      if (width <= 0 || height <= 0) {
        throw new Error(`Invalid image dimensions: ${width}x${height}`);
      }
      
      console.log(`Image loaded successfully: ${width}x${height}`);
      
      // Create canvas and draw image
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        throw new Error('Canvas context not available');
      }
      
      canvas.width = width;
      canvas.height = height;
      
      // Clear canvas and draw image
      ctx.clearRect(0, 0, width, height);
      
      // Handle potential CORS issues with canvas drawing
      try {
        ctx.drawImage(img, 0, 0, width, height);
        console.log('Image drawn to canvas successfully');
      } catch (drawError) {
        throw new Error(`Failed to draw image to canvas (CORS restriction): ${drawError.message}`);
      }
      
      // Convert to blob with better error handling and timeout
      const blob = await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('Canvas to blob conversion timed out'));
        }, 10000);
        
        try {
          const mimeType = imageData.type || 'image/jpeg';
          console.log(`Converting canvas to blob with type: ${mimeType}`);
          
          canvas.toBlob((blob) => {
            clearTimeout(timeout);
            if (blob && blob.size > 0) {
              console.log(`Blob created successfully: ${blob.size} bytes`);
              resolve(blob);
            } else {
              reject(new Error('Failed to create blob from canvas - empty blob'));
            }
          }, mimeType, 0.95);
        } catch (err) {
          clearTimeout(timeout);
          if (err.message.includes('Tainted canvases may not be exported')) {
            reject(new Error('Cannot process this image due to CORS restrictions. The image is from an external domain that doesn\'t allow cross-origin access.'));
          } else {
            reject(new Error(`Canvas toBlob failed: ${err.message}`));
          }
        }
      });
      
      // Generate filename
      const filename = this.generateFilename(imageData.src, imageData.type);
      console.log(`Generated filename: ${filename}`);
      
      // Validate filename
      if (!filename || filename.trim() === '') {
        throw new Error('Generated filename is empty');
      }
      
      // Create File object with extensive validation
      const file = new File([blob], filename, { 
        type: imageData.type || 'image/jpeg',
        lastModified: Date.now()
      });
      
      // Validate File object was created properly
      if (!file) {
        throw new Error('File constructor returned null');
      }
      
      if (!file.name || file.name.trim() === '') {
        throw new Error('File object missing name property');
      }
      
      if (!file.size || file.size <= 0) {
        throw new Error('File object has invalid size');
      }
      
      if (!file.type) {
        throw new Error('File object missing type property');
      }
      
      console.log(`File created successfully: ${file.name} (${file.size} bytes, type: ${file.type})`);
      return file;
      
    } catch (error) {
      console.error(`Image conversion failed for ${imageData.src}:`, error);
      throw new Error(`Image conversion failed: ${error.message}`);
    }
  }

  async fetchImageAsBlob(src) {
    try {
      console.log(`Attempting to fetch image as blob: ${src}`);
      
      // First try with CORS mode for same-origin or CORS-enabled images
      try {
        console.log(`Trying CORS mode for: ${src}`);
        const response = await fetch(src, { 
          mode: 'cors',
          credentials: 'omit',
          cache: 'default'
        });
        
        if (response.ok) {
          const blob = await response.blob();
          if (blob && blob.size > 0) {
            console.log(`Successfully fetched with CORS: ${blob.size} bytes, type: ${blob.type}`);
            return blob;
          }
        }
      } catch (corsError) {
        console.log(`CORS mode failed: ${corsError.message}, trying no-cors mode`);
      }
      
      // Fallback to no-cors mode, but this likely won't work for reading the blob
      try {
        console.log(`Trying no-cors mode for: ${src}`);
        const response = await fetch(src, { 
          mode: 'no-cors',
          credentials: 'omit',
          cache: 'default'
        });
        
        // Note: With no-cors, we get an opaque response that we can't read
        // This is primarily for caching purposes and won't help us get the blob
        if (response.type === 'opaque') {
          console.log(`Got opaque response, cannot read blob content`);
          throw new Error('Cannot read cross-origin image content');
        }
      } catch (noCorsError) {
        console.log(`No-cors mode also failed: ${noCorsError.message}`);
      }
      
      throw new Error('All fetch attempts failed - image is likely CORS-restricted');
      
    } catch (error) {
      console.warn(`Fetch failed for ${src}:`, error.message);
      throw new Error(`Cannot fetch image: ${error.message}`);
    }
  }

  loadImage(src) {
    return new Promise((resolve, reject) => {
      console.log(`Loading image: ${src}`);
      
      let timeoutId = null;
      let resolved = false;
      
      const cleanup = () => {
        if (timeoutId) {
          clearTimeout(timeoutId);
          timeoutId = null;
        }
      };
      
      const safeResolve = (img) => {
        if (!resolved) {
          resolved = true;
          cleanup();
          resolve(img);
        }
      };
      
      const safeReject = (error) => {
        if (!resolved) {
          resolved = true;
          cleanup();
          reject(error);
        }
      };
      
      // Try with crossOrigin first, fallback without it
      const tryLoadWithCors = () => {
        console.log(`Trying CORS load for: ${src}`);
        const corsImg = new Image();
        corsImg.crossOrigin = 'anonymous';
        
        corsImg.onload = () => {
          if (corsImg.naturalWidth > 0 && corsImg.naturalHeight > 0) {
            console.log(`CORS load successful: ${corsImg.naturalWidth}x${corsImg.naturalHeight}`);
            safeResolve(corsImg);
          } else {
            console.warn(`CORS load failed - invalid dimensions for ${src}`);
            tryLoadWithoutCors();
          }
        };
        
        corsImg.onerror = (event) => {
          console.warn(`CORS load failed for ${src}, error:`, event, 'trying without CORS');
          tryLoadWithoutCors();
        };
        
        // Add extra protection against failed CORS loads
        setTimeout(() => {
          if (!resolved) {
            console.warn(`CORS load timeout for ${src}, trying without CORS`);
            tryLoadWithoutCors();
          }
        }, 5000);
        
        corsImg.src = src;
      };
      
      const tryLoadWithoutCors = () => {
        console.log(`Trying normal load for: ${src}`);
        const normalImg = new Image();
        
        normalImg.onload = () => {
          // Check if image loaded properly
          if (normalImg.naturalWidth > 0 && normalImg.naturalHeight > 0) {
            console.log(`Normal load successful: ${normalImg.naturalWidth}x${normalImg.naturalHeight}`);
            safeResolve(normalImg);
          } else {
            safeReject(new Error(`Image loaded but has invalid dimensions: ${src}`));
          }
        };
        
        normalImg.onerror = () => {
          safeReject(new Error(`Failed to load image (both CORS and normal): ${src}`));
        };
        
        normalImg.src = src;
      };
      
      // Start with CORS attempt
      tryLoadWithCors();
      
      // Timeout after 15 seconds
      timeoutId = setTimeout(() => {
        safeReject(new Error(`Image load timeout: ${src}`));
      }, 15000);
    });
  }

  generateFilename(src, type) {
    try {
      const url = new URL(src);
      let filename = url.pathname.split('/').pop() || 'image';
      
      // Remove query parameters
      filename = filename.split('?')[0];
      
      // Ensure proper extension
      const extension = this.getExtensionFromType(type);
      if (!filename.includes('.')) {
        filename += `.${extension}`;
      } else {
        // Replace extension if it doesn't match the type
        const currentExt = filename.split('.').pop().toLowerCase();
        if (currentExt !== extension) {
          filename = filename.replace(/\.[^.]+$/, `.${extension}`);
        }
      }
      
      return filename;
    } catch {
      // Fallback for invalid URLs
      const extension = this.getExtensionFromType(type);
      return `image-${Date.now()}.${extension}`;
    }
  }

  getExtensionFromType(type) {
    const typeMap = {
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'image/gif': 'gif',
      'image/webp': 'webp',
      'image/bmp': 'bmp',
      'image/tiff': 'tiff'
    };
    return typeMap[type] || 'jpg';
  }

  setupMutationObserver() {
    const observer = new MutationObserver((mutations) => {
      let shouldUpdate = false;
      
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // Check if new node contains images
            if (node.tagName === 'IMG' || node.querySelector('img')) {
              shouldUpdate = true;
            }
            
            // Check for background images
            if (this.hasBackgroundImage(node)) {
              shouldUpdate = true;
            }
          }
        });
      });
      
      if (shouldUpdate) {
        // Debounce the detection
        clearTimeout(this.detectionTimeout);
        this.detectionTimeout = setTimeout(() => {
          this.detectImages();
        }, 500);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  setupScrollListener() {
    let scrollTimeout;
    
    const handleScroll = () => {
      clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(() => {
        this.detectImages();
      }, 1000);
    };
    
    window.addEventListener('scroll', handleScroll);
  }

  hasBackgroundImage(element) {
    try {
      const style = window.getComputedStyle(element);
      const backgroundImage = style.backgroundImage;
      return backgroundImage && backgroundImage !== 'none' && backgroundImage.includes('url(');
    } catch {
      return false;
    }
  }
}

// Make sure we have a global instance
let toolspyInstance = null;

// Initialize when page loads
function initializeToolspy() {
  try {
    if (!toolspyInstance) {
      toolspyInstance = new ToolspyContentScript();
      console.log('Toolspy content script initialized');
      
      // Make globally available
      window.toolspyContentScript = toolspyInstance;
      
      // Announce ready state
      chrome.runtime.sendMessage({
        action: 'contentScriptReady',
        url: window.location.href,
        timestamp: Date.now()
      }).catch(() => {
        // Ignore errors if popup is not open
      });
    }
    return toolspyInstance;
  } catch (error) {
    console.error('Failed to initialize Toolspy content script:', error);
  }
}

// Multiple initialization strategies for better reliability
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeToolspy);
} else {
  initializeToolspy();
}

// Also initialize on interactive state
if (document.readyState === 'interactive') {
  setTimeout(initializeToolspy, 100);
}

// Fallback initialization
setTimeout(() => {
  if (!toolspyInstance) {
    console.log('Fallback initialization of Toolspy content script');
    initializeToolspy();
  }
}, 1000); 