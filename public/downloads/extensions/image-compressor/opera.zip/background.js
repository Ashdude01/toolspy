// Background service worker for Toolspy Image Compressor
chrome.runtime.onInstalled.addListener(() => {
  console.log('Toolspy Image Compressor extension installed');
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  // This will open the popup automatically in Manifest V3
  // The popup is defined in manifest.json
});

// Listen for tab updates to refresh image detection
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    // Only inject content script on web pages (not chrome:// pages)
    if (tab.url.startsWith('http://') || tab.url.startsWith('https://')) {
      // Content script is automatically injected via manifest.json
      // No need to manually inject here
    }
  }
});

// Handle messages from content script or popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Relay messages between content script and popup if needed
  if (request.action === 'imagesDetected' || request.action === 'selectionChanged') {
    // Broadcast to all extension windows (popup)
    chrome.runtime.sendMessage(request).catch(() => {
      // Popup might not be open, ignore error
    });
  }
  
  return true; // Keep message channel open
});

// Clean up downloaded files URLs to prevent memory leaks
chrome.downloads.onChanged.addListener((downloadDelta) => {
  if (downloadDelta.state && downloadDelta.state.current === 'complete') {
    // File download completed
    console.log('Download completed:', downloadDelta.id);
  }
}); 