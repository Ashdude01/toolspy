// Shared compression utilities adapted from Toolspy
const COMPRESSION_PRESETS = {
  'balanced': { quality: 85, format: 'original' },
  'high-quality': { quality: 95, format: 'original' },
  'max-compression': { quality: 60, format: 'webp' },
  'web-optimized': { quality: 80, format: 'webp' }
};

class ImageCompressor {
  constructor() {
    this.siteConfig = {
      fileWatermark: 'toolspy'
    };
  }

  async compressImage(file, settings, index = 0) {
    console.log(`Starting compression for ${file.name} with settings:`, settings);
    
    return new Promise((resolve, reject) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      if (!ctx) {
        console.error('Canvas not supported');
        reject(new Error('Canvas not supported'));
        return;
      }
      
      img.onload = async () => {
        try {
          console.log(`Image loaded: ${img.width}x${img.height}`);
          
          // Calculate dimensions
          const { width, height } = this.calculateDimensions(
            img.width, 
            img.height, 
            settings.resize
          );
          
          console.log(`Canvas dimensions: ${width}x${height}`);
          
          canvas.width = width;
          canvas.height = height;
          
          // Draw image
          ctx.drawImage(img, 0, 0, width, height);
          console.log('Image drawn to canvas');
          
          // Determine output format
          const outputFormat = this.getOutputFormat(settings.format, file.type);
          console.log(`Output format: ${outputFormat}`);
          
          // Handle target file size priority
          if (settings.targetFileSize) {
            console.log(`Compressing to target size: ${settings.targetFileSize} bytes`);
            const result = await this.compressToTargetSize(
              canvas, 
              outputFormat, 
              settings.targetFileSize,
              settings.enableProgressive
            );
            if (result) {
              const filename = this.generateCompressedFilename(file.name, outputFormat, index);
              const compressedFile = new File([result], filename, { 
                type: outputFormat 
              });
              console.log(`Target size compression successful: ${compressedFile.size} bytes`);
              resolve(compressedFile);
              return;
            }
          }
          
          // Fallback to quality-based compression
          const quality = settings.quality / 100;
          console.log(`Using quality-based compression: ${quality}`);
          
          canvas.toBlob(
            (blob) => {
              if (blob && blob.size > 0) {
                const filename = this.generateCompressedFilename(file.name, outputFormat, index);
                const compressedFile = new File([blob], filename, { 
                  type: outputFormat 
                });
                console.log(`Quality compression successful: ${compressedFile.size} bytes (filename: ${filename})`);
                resolve(compressedFile);
              } else {
                console.error('Failed to create blob or blob is empty');
                reject(new Error('Failed to compress image - empty result'));
              }
            },
            outputFormat,
            quality
          );
        } catch (error) {
          console.error('Error in compression process:', error);
          reject(error);
        }
      };
      
      img.onerror = (event) => {
        console.error('Failed to load image:', event);
        reject(new Error('Failed to load image'));
      };
      
      console.log('Creating object URL for file...');
      img.src = URL.createObjectURL(file);
    });
  }

  calculateDimensions(originalWidth, originalHeight, resize) {
    if (!resize) {
      return { width: originalWidth, height: originalHeight };
    }
    
    let { width, height } = resize;
    const aspectRatio = originalWidth / originalHeight;
    
    if (width && height) {
      if (resize.maintainAspectRatio) {
        // Fit within bounds while maintaining aspect ratio
        if (width / height > aspectRatio) {
          width = height * aspectRatio;
        } else {
          height = width / aspectRatio;
        }
      }
    } else if (width) {
      height = width / aspectRatio;
    } else if (height) {
      width = height * aspectRatio;
    } else {
      return { width: originalWidth, height: originalHeight };
    }
    
    return { 
      width: Math.round(width), 
      height: Math.round(height) 
    };
  }

  getOutputFormat(format, originalType) {
    if (format === 'original') {
      return originalType;
    }
    
    const formatMap = {
      'jpeg': 'image/jpeg',
      'jpg': 'image/jpeg',
      'png': 'image/png',
      'webp': 'image/webp',
      'avif': 'image/avif',
    };
    
    return formatMap[format] || 'image/jpeg';
  }

  generateCompressedFilename(originalName, outputFormat, index) {
    const extension = this.getExtensionFromMimeType(outputFormat);
    const watermark = this.siteConfig.fileWatermark;
    
    // Simple format: toolspy-compressed-1.jpg
    const fileIndex = index + 1;
    return `${watermark}-compressed-${fileIndex}.${extension}`;
  }

  getExtensionFromMimeType(mimeType) {
    const extensionMap = {
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'image/webp': 'webp',
      'image/avif': 'avif',
      'image/gif': 'gif',
    };
    
    return extensionMap[mimeType] || 'jpg';
  }

  async compressToTargetSize(canvas, outputFormat, targetSizeBytes, enableProgressive) {
    return new Promise((resolve) => {
      let quality = 0.9; // Start with high quality
      let attempts = 0;
      const maxAttempts = 10;
      
      const tryCompress = () => {
        canvas.toBlob(
          (blob) => {
            if (!blob) {
              resolve(null);
              return;
            }
            
            if (blob.size <= targetSizeBytes || attempts >= maxAttempts) {
              resolve(blob);
            } else {
              // Reduce quality and try again
              quality *= 0.8; // Reduce by 20% each time
              attempts++;
              if (quality < 0.1) quality = 0.1; // Minimum quality
              tryCompress();
            }
          },
          outputFormat,
          quality
        );
      };
      
      tryCompress();
    });
  }

  async batchCompress(files, settings, onProgress) {
    console.log('Starting batchCompress with:', files.length, 'files and settings:', settings);
    
    if (!files || files.length === 0) {
      console.error('No files provided to batchCompress');
      throw new Error('No files provided for compression');
    }
    
    const results = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      console.log(`Compressing file ${i + 1}/${files.length}: ${file.name} (${file.size} bytes)`);
      
      onProgress?.(i, files.length, file.name);
      
      try {
        const compressedFile = await this.compressImage(file, settings, i);
        
        if (!compressedFile) {
          throw new Error('Compression returned null result');
        }
        
        const compressionRatio = Math.round(((file.size - compressedFile.size) / file.size) * 100);
        
        console.log(`Successfully compressed ${file.name}: ${file.size} -> ${compressedFile.size} bytes (${compressionRatio}% reduction)`);
        
        results.push({
          file: compressedFile,
          originalSize: file.size,
          compressedSize: compressedFile.size,
          compressionRatio,
          format: this.getExtensionFromMimeType(compressedFile.type),
        });
      } catch (error) {
        console.error(`Failed to compress ${file.name}:`, error);
        // Still continue with other files, but track failures
        results.push({
          file: null,
          originalSize: file.size,
          compressedSize: 0,
          compressionRatio: 0,
          format: 'error',
          error: error.message
        });
      }
    }
    
    console.log(`Batch compression complete: ${results.length} total, ${results.filter(r => r.file).length} successful`);
    onProgress?.(files.length, files.length, 'Complete');
    
    if (results.filter(r => r.file).length === 0) {
      throw new Error('All files failed to compress');
    }
    
    return results;
  }

  formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  async createZipFromFiles(files) {
    // Simple zip creation using JSZip library
    if (typeof JSZip !== 'undefined') {
      const zip = new JSZip();
      
      files.forEach((result, index) => {
        zip.file(result.file.name, result.file);
      });
      
      return await zip.generateAsync({ type: 'blob' });
    }
    
    // Fallback: return null if JSZip not available
    return null;
  }
}

// Make available globally
window.ImageCompressor = ImageCompressor;
window.COMPRESSION_PRESETS = COMPRESSION_PRESETS; 