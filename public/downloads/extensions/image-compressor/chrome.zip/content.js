// Toolspy Image Compressor - Enhanced Content Script
class ToolspyContentScript {
  constructor() {
    this.detectedImages = [];
    this.imageIndex = 0;
    this.setupMessageListener();
    this.init();
  }

  init() {
    // Initial detection
    this.detectImages();
    
    // Watch for new images
    this.setupMutationObserver();
    
    // Detect on scroll for lazy-loaded images
    this.setupScrollListener();
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      console.log('Content script received message:', request);
      
      if (request.action === 'ping') {
        console.log('Ping received, responding with pong');
        sendResponse({ pong: true, timestamp: Date.now() });
        return false; // Synchronous response
      } else if (request.action === 'getImages') {
        sendResponse({
          images: this.detectedImages,
          count: this.detectedImages.length
        });
        return false; // Synchronous response
      } else if (request.action === 'getImageFiles') {
        // Handle async operation properly with better error handling
        (async () => {
          try {
            console.log('Processing getImageFiles request for IDs:', request.imageIds);
            
            // Validate input
            if (!request.imageIds || !Array.isArray(request.imageIds) || request.imageIds.length === 0) {
              throw new Error('Invalid image IDs provided');
            }
            
            const files = await this.getImageFiles(request.imageIds);
            console.log('Sending files response:', files.length, 'files');
            sendResponse({ files, success: true });
          } catch (error) {
            console.error('Error getting image files:', error);
            sendResponse({ files: [], success: false, error: error.message });
          }
        })();
        return true; // Keep message channel open for async response
      }
      return false;
    });
  }

  detectImages() {
    this.detectedImages = [];
    this.imageIndex = 0;

    // Detect regular img elements
    this.detectRegularImages();
    
    // Detect background images
    this.detectBackgroundImages();

    console.log(`Detected ${this.detectedImages.length} images`);
    
    // Notify popup about image count
    chrome.runtime.sendMessage({
      action: 'imagesDetected',
      count: this.detectedImages.length
    }).catch(() => {
      // Ignore errors if popup is not open
    });
  }

  detectRegularImages() {
    const images = document.querySelectorAll('img');
    
    images.forEach(img => {
      if (this.isValidImage(img)) {
        const imageData = {
          id: `img-${this.imageIndex++}`,
          src: img.src,
          alt: img.alt || 'Image',
          width: img.naturalWidth || img.width,
          height: img.naturalHeight || img.height,
          element: img,
          type: this.getImageType(img.src),
          isBackground: false
        };
        
        this.detectedImages.push(imageData);
        img.setAttribute('data-toolspy-id', imageData.id);
      }
    });
  }

  detectBackgroundImages() {
    const elements = document.querySelectorAll('*');
    
    elements.forEach(element => {
      const style = window.getComputedStyle(element);
      const backgroundImage = style.backgroundImage;
      
      if (backgroundImage && backgroundImage !== 'none') {
        const urlMatch = backgroundImage.match(/url\(["']?(.*?)["']?\)/);
        if (urlMatch && urlMatch[1]) {
          const src = urlMatch[1];
          
          // Skip data URLs and invalid images
          if (src.startsWith('data:') || src.includes('placeholder')) {
            return;
          }
          
          // Check if already detected
          if (!this.detectedImages.find(img => img.src === src)) {
            const imageData = {
              id: `bg-${this.imageIndex++}`,
              src: src,
              alt: 'Background Image',
              width: element.offsetWidth,
              height: element.offsetHeight,
              element: element,
              type: this.getImageType(src),
              isBackground: true
            };
            
            this.detectedImages.push(imageData);
            element.setAttribute('data-toolspy-bg-id', imageData.id);
          }
        }
      }
    });
  }

  isValidImage(img) {
    // Check if image has valid source and dimensions
    if (!img.src || img.src.startsWith('data:image/svg') || img.src.includes('placeholder')) {
      return false;
    }
    
    // Filter out small images (likely icons)
    const minSize = 50;
    const width = img.naturalWidth || img.width;
    const height = img.naturalHeight || img.height;
    
    return width >= minSize && height >= minSize;
  }

  getImageType(src) {
    const extension = src.split('.').pop()?.split('?')[0]?.toLowerCase();
    const typeMap = {
      'jpg': 'image/jpeg',
      'jpeg': 'image/jpeg',
      'png': 'image/png',
      'gif': 'image/gif',
      'webp': 'image/webp',
      'bmp': 'image/bmp',
      'tiff': 'image/tiff',
      'svg': 'image/svg+xml'
    };
    return typeMap[extension] || 'image/jpeg';
  }

  async getImageFiles(imageIds) {
    if (!imageIds || imageIds.length === 0) {
      throw new Error('No image IDs provided');
    }

    const selectedImageData = this.detectedImages.filter(img => 
      imageIds.includes(img.id)
    );
    
    console.log('Selected image data:', selectedImageData.length, 'out of', imageIds.length);
    
    if (selectedImageData.length === 0) {
      throw new Error('No matching images found for the provided IDs. The page may have been refreshed or the images may have changed.');
    }

    const files = [];
    const failedImages = [];
    
    // Process images with better error tracking
    for (let i = 0; i < selectedImageData.length; i++) {
      const imageData = selectedImageData[i];
      try {
        console.log(`Processing image ${i + 1}/${selectedImageData.length}: ${imageData.src}`);
        const file = await this.imageToFile(imageData);
        if (file && file.size > 0) {
          files.push(file);
          console.log('Successfully converted image to file:', file.name, `(${file.size} bytes)`);
        } else {
          throw new Error('Generated file is empty or invalid');
        }
      } catch (error) {
        console.error(`Failed to convert image ${i + 1} to file:`, imageData.src, error.message);
        failedImages.push({
          src: imageData.src,
          error: error.message
        });
        // Continue with other images even if one fails
      }
    }
    
    console.log(`Conversion complete: ${files.length} successful, ${failedImages.length} failed`);
    
    if (files.length === 0) {
      const errorDetails = failedImages.length > 0 
        ? `All images failed to load. Common issues: ${failedImages[0].error}` 
        : 'No images could be processed';
      throw new Error(`${errorDetails}. Try refreshing the page and selecting different images.`);
    }
    
    if (failedImages.length > 0) {
      console.warn(`${failedImages.length} images failed to convert:`, failedImages);
    }
    
    return files;
  }

  async imageToFile(imageData) {
    try {
      // First try to load the image to ensure it's accessible
      const img = await this.loadImage(imageData.src);
      
      // Create canvas and draw image
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      canvas.width = img.naturalWidth || img.width || 300;
      canvas.height = img.naturalHeight || img.height || 300;
      
      // Ensure canvas size is valid
      if (canvas.width <= 0 || canvas.height <= 0) {
        throw new Error('Invalid image dimensions');
      }
      
      ctx.drawImage(img, 0, 0);
      
      // Convert to blob with better error handling
      const blob = await new Promise((resolve, reject) => {
        try {
          canvas.toBlob((blob) => {
            if (blob && blob.size > 0) {
              resolve(blob);
            } else {
              reject(new Error('Failed to create blob from canvas - empty blob'));
            }
          }, imageData.type || 'image/jpeg', 0.95);
        } catch (err) {
          reject(new Error(`Canvas toBlob failed: ${err.message}`));
        }
      });
      
      // Generate filename
      const filename = this.generateFilename(imageData.src, imageData.type);
      
      // Create File object
      const file = new File([blob], filename, { 
        type: imageData.type || 'image/jpeg',
        lastModified: Date.now()
      });
      
      return file;
      
    } catch (error) {
      console.error(`Image conversion failed for ${imageData.src}:`, error);
      throw new Error(`Image conversion failed: ${error.message}`);
    }
  }

  loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      
      // Try with crossOrigin first, fallback without it
      const tryLoadWithCors = () => {
        const corsImg = new Image();
        corsImg.crossOrigin = 'anonymous';
        
        corsImg.onload = () => resolve(corsImg);
        corsImg.onerror = () => {
          console.warn(`CORS load failed for ${src}, trying without CORS`);
          tryLoadWithoutCors();
        };
        
        corsImg.src = src;
      };
      
      const tryLoadWithoutCors = () => {
        const normalImg = new Image();
        
        normalImg.onload = () => {
          // Check if image loaded properly
          if (normalImg.naturalWidth > 0 && normalImg.naturalHeight > 0) {
            resolve(normalImg);
          } else {
            reject(new Error(`Image loaded but has invalid dimensions: ${src}`));
          }
        };
        
        normalImg.onerror = () => {
          reject(new Error(`Failed to load image (both CORS and normal): ${src}`));
        };
        
        normalImg.src = src;
      };
      
      // Start with CORS attempt
      tryLoadWithCors();
      
      // Timeout after 10 seconds
      setTimeout(() => {
        reject(new Error(`Image load timeout: ${src}`));
      }, 10000);
    });
  }

  generateFilename(src, type) {
    try {
      const url = new URL(src);
      let filename = url.pathname.split('/').pop() || 'image';
      
      // Remove query parameters
      filename = filename.split('?')[0];
      
      // Ensure proper extension
      const extension = this.getExtensionFromType(type);
      if (!filename.includes('.')) {
        filename += `.${extension}`;
      } else {
        // Replace extension if it doesn't match the type
        const currentExt = filename.split('.').pop().toLowerCase();
        if (currentExt !== extension) {
          filename = filename.replace(/\.[^.]+$/, `.${extension}`);
        }
      }
      
      return filename;
    } catch {
      // Fallback for invalid URLs
      const extension = this.getExtensionFromType(type);
      return `image-${Date.now()}.${extension}`;
    }
  }

  getExtensionFromType(type) {
    const typeMap = {
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'image/gif': 'gif',
      'image/webp': 'webp',
      'image/bmp': 'bmp',
      'image/tiff': 'tiff'
    };
    return typeMap[type] || 'jpg';
  }

  setupMutationObserver() {
    const observer = new MutationObserver((mutations) => {
      let shouldUpdate = false;
      
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // Check if new node contains images
            if (node.tagName === 'IMG' || node.querySelector('img')) {
              shouldUpdate = true;
            }
            
            // Check for background images
            if (this.hasBackgroundImage(node)) {
              shouldUpdate = true;
            }
          }
        });
      });
      
      if (shouldUpdate) {
        // Debounce the detection
        clearTimeout(this.detectionTimeout);
        this.detectionTimeout = setTimeout(() => {
          this.detectImages();
        }, 500);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  setupScrollListener() {
    let scrollTimeout;
    
    const handleScroll = () => {
      clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(() => {
        this.detectImages();
      }, 1000);
    };
    
    window.addEventListener('scroll', handleScroll);
  }

  hasBackgroundImage(element) {
    try {
      const style = window.getComputedStyle(element);
      const backgroundImage = style.backgroundImage;
      return backgroundImage && backgroundImage !== 'none' && backgroundImage.includes('url(');
    } catch {
      return false;
    }
  }
}

// Make sure we have a global instance
let toolspyInstance = null;

// Initialize when page loads
function initializeToolspy() {
  if (!toolspyInstance) {
    toolspyInstance = new ToolspyContentScript();
    console.log('Toolspy content script initialized');
    
    // Announce ready state
    chrome.runtime.sendMessage({
      action: 'contentScriptReady',
      url: window.location.href
    }).catch(() => {
      // Ignore errors if popup is not open
    });
  }
  return toolspyInstance;
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeToolspy);
} else {
  initializeToolspy();
}

// Ensure instance is available globally
window.toolspyContentScript = toolspyInstance; 